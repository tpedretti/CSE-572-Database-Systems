REM  This produces a readable 2-column format for data dictionary output

column table format a30 wrapped
column comments format a100 wrapped
set linesize 132
set pagesize 40
set pause on
set pause "Press return to continue --> "

